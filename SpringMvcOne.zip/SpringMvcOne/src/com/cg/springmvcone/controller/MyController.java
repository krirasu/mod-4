package com.cg.springmvcone.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.springmvcone.dto.Employee;
import com.cg.springmvcone.service.IEmployeeService;

@Controller
public class MyController
{
	@Autowired
	IEmployeeService employeeservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp,Map<String,Object>model)/*model attribute is used to link jsp page with dto*/
	{
		List<String> myDesg=new ArrayList<>();
		myDesg.add("Software Engg");
		myDesg.add("Senior Consultant");
		myDesg.add("Manager");
		model.put("desg", myDesg);
		return "addEmployee";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid@ModelAttribute("my") Employee emp,BindingResult result,Map<String,Object>model)
	{
		long id=0;
		if(result.hasErrors())
		{
			List<String> myDesg=new ArrayList<>();
			myDesg.add("Software Engg");
			myDesg.add("Senior Consultant");
			myDesg.add("Manager");
			model.put("desg", myDesg);
			return new ModelAndView("addEmployee");
		}
		else
		{
		 id=employeeservice.addEmployee(emp);
		 return new ModelAndView("Success", "edata", id);
		}
		//System.out.println("Name is "+emp.getEmpName());
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Employee> myAllData=employeeservice.showAllEmployee();
		return new ModelAndView("showall", "temp", myAllData);	
	}
	/***********************************************/
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteEmployee()
	{
		return "deleteemployee";
	}
	
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("eid") long id)/*If we need more than one parameters in request param write it with comma in between*/
	{
		employeeservice.deleteEmployee(id);
		System.out.println("Id is..."+id);
		return "Success";
	}
	/***********************************************/
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String ModifyEmployeeData(@ModelAttribute("my") Employee emp)
	{
		return "modify";

	}
	@RequestMapping(value="modifydata", method=RequestMethod.GET)
	public ModelAndView modifyData(@RequestParam("employeeid") int empId,
			@ModelAttribute("my") Employee emp)
	{
		emp=employeeservice.searchEmployee(empId);
		System.out.println(emp.toString());
		return new ModelAndView("modify","temp", emp);	
	}
	@RequestMapping(value="updated", method=RequestMethod.POST)
	public String updateEmployee(@ModelAttribute("my") Employee emp)	
	{
		employeeservice.updateEmployee(emp);
		return "Success";
	}
	/*****************************************/
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String retrieveEmployee(@ModelAttribute("my") Employee emp)
	{
		return "retrieveemployee";	
	}
	
	@RequestMapping(value="doretrieve",method=RequestMethod.GET)
	public ModelAndView getSingleEmployee
	(@RequestParam("eid") int id) 
	{
		Employee empOne=employeeservice.searchEmployee(id);
		return new ModelAndView("singleemployee","temp",empOne);
	}
}
