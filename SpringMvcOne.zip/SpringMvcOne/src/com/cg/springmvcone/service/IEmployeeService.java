package com.cg.springmvcone.service;

import java.util.List;

import com.cg.springmvcone.dto.Employee;

public interface IEmployeeService
{
	public long addEmployee(Employee emp);
	public List<Employee> showAllEmployee();
	public void deleteEmployee(long id);
	public void updateEmployee(Employee emp);
	public Employee searchEmployee(long id);
}
