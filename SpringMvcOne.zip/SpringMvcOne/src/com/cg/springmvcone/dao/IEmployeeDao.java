package com.cg.springmvcone.dao;
import java.util.List;
import com.cg.springmvcone.dto.Employee;

public interface IEmployeeDao 
{
	public long addEmployee(Employee emp);
	public List<Employee> showAllEmployee();
	public void deleteEmployee(long empId);
	public void updateEmployee(Employee emp);
	public Employee searchEmployee(long id);
}
