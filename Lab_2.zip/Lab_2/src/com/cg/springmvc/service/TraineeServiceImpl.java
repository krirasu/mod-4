package com.cg.springmvc.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.dao.ITraineeDao;
import com.cg.springmvc.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{
	@Autowired
	ITraineeDao traineedao;
	@Override
	public long addTrainee(Trainee tr) 
	{
		return traineedao.addTrainee(tr);
	}

	@Override
	public void deleteTrainee(long traineeId) 
	{
		traineedao.deleteTrainee(traineeId);	
	}

	@Override
	public void modifyTrainee(Trainee tr) 
	{
		traineedao.modifyTrainee(tr);
	}

	@Override
	public Trainee retrieveTrainee(long traineeId) 
	{
		return traineedao.retrieveTrainee(traineeId);
	}

	@Override
	public List<Trainee> showAllTrainee() 
	{
		return traineedao.showAllTrainee();
	}
}
