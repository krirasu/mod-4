package com.cg.springmvc.dao;
import java.util.List;
import com.cg.springmvc.dto.Trainee;

public interface ITraineeDao 
{
	public long addTrainee(Trainee tr);
	public void deleteTrainee(long traineeId);
	public void modifyTrainee(Trainee tr);
	public Trainee retrieveTrainee(long traineeId);
	public List<Trainee> showAllTrainee();
}
