package com.cg.springmvc.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.springmvc.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public long addTrainee(Trainee tr) 
	{
		entitymanager.persist(tr);	
		entitymanager.flush();
		return tr.getTraineeId();		
	}

	@Override
	public void deleteTrainee(long traineeId) 
	{
		Query queryOne=entitymanager.createQuery("DELETE FROM Trainee WHERE traineeId=:tid");
		queryOne.setParameter("tid",traineeId);
		queryOne.executeUpdate();	
		
	}

	@Override
	public void modifyTrainee(Trainee tr)
	{
		entitymanager.merge(tr);
	}

	@Override
	public Trainee retrieveTrainee(long traineeId) 
	{
		Query queryTwo=entitymanager.createQuery("FROM Trainee where traineeId=:trainee_id");
		queryTwo.setParameter("trainee_id",traineeId);
		Trainee trainee=(Trainee) queryTwo.getSingleResult();
		/*Trainee trainee=entitymanager.find(Trainee.class, traineeId);*/
		System.out.println(trainee.toString());
		return trainee;
	}

	@Override
	public List<Trainee> showAllTrainee() 
	{
		Query queryThree=entitymanager.createQuery("FROM Trainee");
		List<Trainee> myList=queryThree.getResultList();
		return myList;
	}
}
