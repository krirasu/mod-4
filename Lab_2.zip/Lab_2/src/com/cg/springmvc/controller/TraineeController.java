package com.cg.springmvc.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc.dto.Trainee;
import com.cg.springmvc.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="menu",method=RequestMethod.GET)
	public String getAll(@RequestParam("txtUnm") String name,
			@RequestParam("txtPwd") String password)
	{
		if(name.equalsIgnoreCase("admin")&&password.equalsIgnoreCase("admin"))
		{
		return "menu";
		}
	return "error";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee tr,Map<String,Object>model)/*model attribute is used to link jsp page with dto*/
	{
		List<String> myDom=new ArrayList<>();
		myDom.add("JEE");
		myDom.add(".NET");
		myDom.add("Oracle");
		myDom.add("Mainframe");
		model.put("dom", myDom);
		return "addTrainee";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid @ModelAttribute("my") Trainee tr,BindingResult result,Map<String,Object>model)
	{
		long id=0;
		if(result.hasErrors())
		{
			List<String> myDom=new ArrayList<>();
			myDom.add("JEE");
			myDom.add(".NET");
			myDom.add("Oracle");
			myDom.add("Mainframe");
			model.put("dom", myDom);
			return new ModelAndView("addTrainee");
		}
		else
		{
		 id=traineeservice.addTrainee(tr);
		 return new ModelAndView("Success", "tdata", id);
		}
	}
/*****************************************/		
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "deleteTrainee";
	}
	
	@RequestMapping(value="deletedata", method=RequestMethod.GET)
	public ModelAndView deleteData(@RequestParam("id") int id)
	{

		Trainee trainee=traineeservice.retrieveTrainee(id);		
		return new ModelAndView("showDelete","temp", trainee);

	}
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public String traineeDelete(@RequestParam("tid") int id)/*If we need more than one parameters in request param write it with comma in between*/
	{
		traineeservice.deleteTrainee(id);
		return "Success";
	}
/*****************************************/
	@RequestMapping(value="modify", method=RequestMethod.GET)
	public String ModifyTraineeData(@ModelAttribute("my") Trainee tr)
	{
		return "modify";

	}
	@RequestMapping(value="modifydata", method=RequestMethod.GET)
	public ModelAndView modifyData(@RequestParam("traineeid") int traId,
			@ModelAttribute("my") Trainee tr)
	{
		tr=traineeservice.retrieveTrainee(traId);
		System.out.println(tr.toString());
		return new ModelAndView("modify","temp", tr);	
	}
	@RequestMapping(value="update", method=RequestMethod.POST)
	public String modifyTrainee(@ModelAttribute("my") Trainee tr)	
	{
		traineeservice.modifyTrainee(tr);
		return "Success";
	}
/*****************************************/
	@RequestMapping(value="retrieve",method=RequestMethod.GET)
	public String retrieveTrainee(@ModelAttribute("my") Trainee tr)
	{
		return "retrievetrainee";	
	}
	
	@RequestMapping(value="doretrieve",method=RequestMethod.GET)
	public ModelAndView getSingleTrainee
	(@RequestParam("tid") long id) 
	{
		Trainee trOne=traineeservice.retrieveTrainee(id);
		return new ModelAndView("singletrainee","temp",trOne);
	}
/*****************************************/	
	@RequestMapping(value="retrieveall",method=RequestMethod.GET)
	public ModelAndView showAllTrainee()
	{
		List<Trainee> myAllData=traineeservice.showAllTrainee();
		return new ModelAndView("retrieveall", "temp", myAllData);	
	}
}
