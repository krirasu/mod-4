package com.cg.springmvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee")
public class Trainee 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="trainee_seq")
	@SequenceGenerator(name="trainee_seq",sequenceName="trainee_seq_tid")
	@Column(name="trainee_id")
	private Long traineeId;
	@Column(name="trainee_name")
	@NotEmpty(message="Name should not be empty")
	private String traineeName;
	@Column(name="trainee_location")
	private String traineeLocation;
	@Column(name="trainee_domain")
	private String traineeDomain;
	
	public Long getTraineeId() 
	{
		return traineeId;
	}
	public void setTraineeId(Long traineeId)
	{
		this.traineeId = traineeId;
	}
	public String getTraineeName() 
	{
		return traineeName;
	}
	public void setTraineeName(String traineeName) 
	{
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() 
	{
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) 
	{
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() 
	{
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) 
	{
		this.traineeDomain = traineeDomain;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeLocation=" + traineeLocation
				+ ", traineeDomain=" + traineeDomain + "]";
	}
	
}
